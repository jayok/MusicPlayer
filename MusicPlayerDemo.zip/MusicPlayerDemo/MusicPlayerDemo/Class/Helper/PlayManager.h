//
//  PlayManager.h
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/16.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@protocol PlaymanagerDelegate <NSObject>
//把播放的时间和进度信息传递过去
- (void)playManagerDelegateFetchTotalTime:(NSString *)totalTime currentTime:(NSString *)currenytTime progress:(CGFloat)progress;
//自动播放到下一首
- (void)playToNextMusic;
@end

@interface PlayManager : NSObject
//声明代理
@property (nonatomic, weak)id<PlaymanagerDelegate>delegate;
//playManager单例
+(instancetype)shardPlayManager;
//准备去播放
- (void)prepareToPlayMusicWithUrl:(NSString *)url;
//播放
- (void)playMusic;
//暂停
- (void)pauseMusic;
//快进快退
- (void)playMusicWithSliderValue:(CGFloat)progress;
//是否正在播放
- (BOOL)isPlaying;
//图片转动动画
- (void)playMusicAddTransformWithImageView:(UIImageView *)imageView;
//暂停动画
-(void)pauseLayer:(CALayer*)layer;
//重新开始动画
-(void)resumeLayer:(CALayer*)layer;
@end
