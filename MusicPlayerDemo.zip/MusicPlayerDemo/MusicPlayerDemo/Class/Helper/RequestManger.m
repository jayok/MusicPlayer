//
//  RequestManger.m
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/15.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import "RequestManger.h"

@interface RequestManger ()
@property (nonatomic, strong)NSMutableArray *musicArray;//存放数据
@end

@implementation RequestManger
//RequestManger单例
+ (instancetype)shardManger {
    static RequestManger *manger = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[RequestManger alloc] init];
    });
    return manger;
}
//通过URL获取数据
- (void)fetchDataWithURL:(NSString *)url updataUI:(MusicBlock)block {
    //子线程用来处理耗时操作
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSArray *array = [NSArray arrayWithContentsOfURL:[NSURL URLWithString:url]];
        for (NSDictionary *dic in array) {
            MusicModel *model = [[MusicModel alloc] init];
            [model setValuesForKeysWithDictionary:dic];
            [self.musicArray addObject:model];
        }
        //回到主线程，主要用来刷新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            block();
        });
        
    });
}
//返回数据个数
- (NSInteger)numberOfArrayCount {
    return self.musicArray.count;
}
//返回对应下标的元素
- (MusicModel *)returnMusicAtIndex:(NSInteger)index {
    return self.musicArray[index];
}
- (NSMutableArray *)musicArray {
    if (!_musicArray) {
        _musicArray = [NSMutableArray array];
    }
    return _musicArray;
}
@end
