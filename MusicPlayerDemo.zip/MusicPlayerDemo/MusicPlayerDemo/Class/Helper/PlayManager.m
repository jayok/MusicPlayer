//
//  PlayManager.m
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/16.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import "PlayManager.h"

@interface PlayManager ()
//播放器
@property (nonatomic, retain)AVPlayer *player;
//定时器
@property (nonatomic, strong)NSTimer *timer;
@end

@implementation PlayManager
//playManager单例
+ (instancetype)shardPlayManager {
    static PlayManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[PlayManager alloc] init];
    });
    return manager;
}
//暂停
- (void)pauseMusic {
    [self.player pause];
    [self closeTimer];
}
//播放
- (void)playMusic {
    [self.player play];
    [self startTimer];
}
//准备去播放
- (void)prepareToPlayMusicWithUrl:(NSString *)url {
    if (!url) { //如果网址为空，则不执行任何操作
        return;
    }
    //判断当前有没有正在播放的item
    if (self.player.currentItem) {
        //移除观察者
        [self.player.currentItem removeObserver:self forKeyPath:@"status"];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    }
    //创建item
    AVPlayerItem *item = [[AVPlayerItem alloc] initWithURL:[NSURL URLWithString:url]];
    //添加观察者,观察item的状态
    [item addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    //替换当前item
    [self.player replaceCurrentItemWithPlayerItem:item];
    
    //播放完成后自动跳转到下一首
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playMusicEnd) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    
    
}
//自动播放下一首事件
- (void)playMusicEnd {
    
    if ([self.delegate respondsToSelector:@selector(playToNextMusic)]) {
        [self.delegate playToNextMusic];
        
    }
}
//观察者事件
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    //得到属性改变后的状态
    AVPlayerItemStatus status = [change[@"new"] integerValue];
    switch (status) {
        case AVPlayerItemStatusUnknown:
            NSLog(@"未知错误");
            break;
        case AVPlayerItemStatusReadyToPlay:
            NSLog(@"加载完成，准备播放");
            //调用播放方法
            [self playMusic];
            break;
        case AVPlayerItemStatusFailed:
            NSLog(@"网络异常，加载失败");
            break;
        default:
            break;
    }
}
//获取总时长
- (NSInteger)fetchTotalTime {
    //获取当前播放歌曲的总时间
    CMTime time = self.player.currentItem.duration;
    //播放秒数 = time.value/time.timescale
    if (time.timescale == 0) {
        return 0;
    }
    return time.value/time.timescale;
}
//获取当前歌曲播放的时间
- (NSInteger)fetchCurrentTime {
    //获取当前播放的时间
    CMTime time = self.player.currentItem.currentTime;
    if (time.timescale == 0) {
        return 0;
    }
    return time.value / time.timescale;
}
//获取当前播放进度
- (CGFloat)fetchProgressValue {
    return [self fetchCurrentTime] / (CGFloat)[self fetchTotalTime];
}
//将秒数转换成类似00:00的时间格式
- (NSString *)changeSecondsTime:(NSInteger)time {
    NSInteger min = time / 60;
    NSInteger seconds = time % 60;
    return [NSString stringWithFormat:@"%.2ld:%.2ld", min, seconds];
}
//快进快退
- (void)playMusicWithSliderValue:(CGFloat)progress {
    
    //滑动之前先暂停歌曲
    [self pauseMusic];
    
    [self.player seekToTime:CMTimeMake([self fetchTotalTime] * progress, 1) completionHandler:^(BOOL finished) {
        if (finished) { //完成以后继续播放
            [self playMusic];
        }
    }];
}
//定时器回调方法
- (void)timerAction {
    
    if ([self.delegate respondsToSelector:@selector(playManagerDelegateFetchTotalTime:currentTime:progress:)]) {//判断代理是否实现
        NSString *totalTime = [self changeSecondsTime:[self fetchTotalTime]];
        NSString *currentTime = [self changeSecondsTime:[self fetchCurrentTime]];
        CGFloat progress = [self fetchProgressValue];
        [self.delegate playManagerDelegateFetchTotalTime:totalTime currentTime:currentTime progress:progress];
    }

}
//开始定时器
- (void)startTimer {
    [self.timer fire];
}
//关闭定时器
- (void)closeTimer {
    [self.timer invalidate];
    //失效后置空
    self.timer = nil;
}
//是否正在播放
- (BOOL)isPlaying {
    if (self.player.rate == 0) {
        return NO;
    }
    return YES;
}
//图片转动动画
- (void)playMusicAddTransformWithImageView:(UIImageView *)imageView {
    
        CABasicAnimation *basic = [CABasicAnimation animation];
        basic.keyPath = @"transform.rotation.z";
        basic.duration = [self fetchTotalTime];
        basic.repeatDuration = MAXFLOAT;
        basic.toValue = @(M_PI / 6);
        basic.cumulative = YES;
        [imageView.layer addAnimation:basic forKey:@"basic"];
    
}
//暂停动画
-(void)pauseLayer:(CALayer*)layer {
    CFTimeInterval pausedTime = [layer convertTime:CACurrentMediaTime() fromLayer:nil];
    layer.speed = 0.0;
    layer.timeOffset = pausedTime;
}
//重新开始动画
-(void)resumeLayer:(CALayer*)layer {
    CFTimeInterval pausedTime = [layer timeOffset];
    layer.speed = 1.0;
    layer.timeOffset = 0.0;
    layer.beginTime = 0.0;
    CFTimeInterval timeSincePause = [layer convertTime:CACurrentMediaTime() fromLayer:nil] -    pausedTime;
    layer.beginTime = timeSincePause;
}

//懒加载
- (AVPlayer *)player {
    if (!_player) {
        _player = [[AVPlayer alloc] init];
    }
    return _player;
}
- (NSTimer *)timer {
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(timerAction) userInfo:nil repeats:YES];
    }
    return _timer;
}
@end
