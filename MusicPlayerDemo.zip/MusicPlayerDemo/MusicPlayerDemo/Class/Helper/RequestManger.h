//
//  RequestManger.h
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/15.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MusicModel;
typedef void(^MusicBlock)();

@interface RequestManger : NSObject
//RequestManger单例
+ (instancetype)shardManger;
//通过URL获取数据
- (void)fetchDataWithURL:(NSString *)url updataUI:(MusicBlock)block;
//返回数据个数
- (NSInteger)numberOfArrayCount;
//返回对应下标的元素
- (MusicModel *)returnMusicAtIndex:(NSInteger)index;
@end
