//
//  MusicModel.m
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/15.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import "MusicModel.h"

@implementation MusicModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}
@end
