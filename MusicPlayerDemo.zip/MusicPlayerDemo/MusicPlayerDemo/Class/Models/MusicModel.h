//
//  MusicModel.h
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/15.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MusicModel : NSObject
@property (nonatomic, strong)NSString *name;//歌曲名
@property (nonatomic, strong)NSString *mp3Url;//音乐播放网址
@property (nonatomic, strong)NSString *picUrl;//歌曲图片
@property (nonatomic, strong)NSString *singer;//歌手
@property (nonatomic, strong)NSString *lyric;//歌词
@end
