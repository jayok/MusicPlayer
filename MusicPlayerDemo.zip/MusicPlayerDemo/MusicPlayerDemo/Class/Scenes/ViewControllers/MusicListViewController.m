//
//  MusicListViewController.m
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/15.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import "MusicListViewController.h"

@interface MusicListViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation MusicListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    //获取数据并刷新UI
    [[RequestManger shardManger] fetchDataWithURL:kUrl updataUI:^{
        [self.tableView reloadData];
    }];
    //注册CELL
    [self.tableView registerNib:[UINib nibWithNibName:@"MusicListCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"musicListCell"];
}
#pragma mark - tableView代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[RequestManger shardManger] numberOfArrayCount];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MusicListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"musicListCell"];
    MusicModel *model = [[RequestManger shardManger] returnMusicAtIndex:indexPath.row];
    [cell cellGetDataForModel:model];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PlayMusicViewController *playVC = [PlayMusicViewController shardViewManager];
    playVC.index = indexPath.row;
    [self.navigationController pushViewController:playVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
