//
//  PlayMusicViewController.h
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/16.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayMusicViewController : UIViewController
+ (instancetype)shardViewManager;
//记录点击的是第几首个
@property (nonatomic, assign)NSInteger index;
//记录正在播放的下标
@property (nonatomic, assign)NSInteger currentIndex;
@end
