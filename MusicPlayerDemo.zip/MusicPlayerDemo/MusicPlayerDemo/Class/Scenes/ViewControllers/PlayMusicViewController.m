//
//  PlayMusicViewController.m
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/16.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import "PlayMusicViewController.h"

@interface PlayMusicViewController ()<PlaymanagerDelegate, UITableViewDataSource>
//歌词页面
@property (weak, nonatomic) IBOutlet UITableView *tableView;
//歌曲背景
@property (weak, nonatomic) IBOutlet UIImageView *mp3Pic;
//当前时间
@property (weak, nonatomic) IBOutlet UILabel *currentTime;
//总共时间
@property (weak, nonatomic) IBOutlet UILabel *totalTime;
//当前进度
@property (weak, nonatomic) IBOutlet UISlider *slider;
//歌词时间数组
@property (nonatomic, strong) NSMutableArray *timeArray;
//歌词数组
@property (nonatomic, strong) NSMutableArray *lyicArray;

@end

@implementation PlayMusicViewController
//单例
+ (instancetype)shardViewManager {
    static PlayMusicViewController *manger = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"playMusic"];
    });
    return manger;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    //为了防止点击第一首歌时不能播放
    self.currentIndex = -1;
    //让约束提前生效
    [self.mp3Pic layoutIfNeeded];
    //让背景图变成圆形
    self.mp3Pic.layer.masksToBounds = YES;
    self.mp3Pic.layer.cornerRadius = CGRectGetWidth(self.mp3Pic.frame) / 2.0;
    //设置代理
    [PlayManager shardPlayManager].delegate = self;
    
    //设置tableView代理
    self.tableView.dataSource = self;
    //设置分割线
    self.tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    //设置用户交互
    self.tableView.userInteractionEnabled = NO;
    //注册cell
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
}
//视图将要出现
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //为了防止点同一首歌重新播放的情况发生
    if (self.index != self.currentIndex) {
        self.currentIndex = self.index;
        //设置信息
        [self setMusicInfoWithIndex:self.currentIndex];
    }
}
//设置播放信息
- (void)setMusicInfoWithIndex:(NSInteger)index {
    //清楚数组信息
    if (self.timeArray) {
        [self.timeArray removeAllObjects];
        [self.lyicArray removeAllObjects];
    }
    //获取对应下标的音乐
    MusicModel *model = [[RequestManger shardManger] returnMusicAtIndex:index];
    //子线程用来处理耗时的操作
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        //播放
        [[PlayManager shardPlayManager] prepareToPlayMusicWithUrl:model.mp3Url];
        //歌词
        //根据\n对歌词进行分割
        NSArray *array =  [model.lyric componentsSeparatedByString:@"\n"];
        
        for (NSString *string in array) {
            //根据“]”把时间和歌词分离
            NSArray *array1 = [string componentsSeparatedByString:@"]"];
            //判断如果存在时间，歌词两个元素，再把时间和歌词进行分割
            if (array1.count == 2) {
                NSString *time = [array1[0] substringWithRange:NSMakeRange(1, 5)];
                [self.timeArray addObject:time];
                [self.lyicArray addObject:array1[1]];
            }
            //测试
            //                NSLog(@"%@", model.lyric);
            //                for (int i = 0; i < self.timeArray.count; i++) {
            //                    NSLog(@"%@%@", self.timeArray[i], self.lyicArray[i]);
            //                }
        }
        

        //主线程主要用来刷新UI(使用完子线程要回到主线程)
        dispatch_async(dispatch_get_main_queue(), ^{
           
            //设置界面

            //题目
            self.title = model.name;
            //背景图
            [self.mp3Pic sd_setImageWithURL:[NSURL URLWithString:model.picUrl] placeholderImage:nil];
            //背景图复原
//            self.mp3Pic.transform = CGAffineTransformIdentity;
            self.mp3Pic.transform = CGAffineTransformMakeRotation(0);
            //刷新UI
            [self.tableView reloadData];
        });
        
    });
}
//快进快退事件
- (IBAction)sliderAction:(UISlider *)sender {
    [[PlayManager shardPlayManager] playMusicWithSliderValue:sender.value];
}

//播放上一首
- (IBAction)playLastOne:(UIButton *)sender {
    //如果是第一首歌曲，则播放最后一首
    if ((self.currentIndex == 0)) {
        self.currentIndex = [[RequestManger shardManger] numberOfArrayCount] - 1;
    } else {
        self.currentIndex--;
    }
    //设置信息
    [self setMusicInfoWithIndex:self.currentIndex];
}
//播放或暂停
- (IBAction)palyOrPauseAction:(UIButton *)sender {
    if ([[PlayManager shardPlayManager] isPlaying]) {
        //暂停音乐
        [[PlayManager shardPlayManager] pauseMusic];
//        [[PlayManager shardPlayManager] pauseLayer:self.mp3Pic.layer];
    } else {
        //重新播放音乐
        [[PlayManager shardPlayManager] playMusic];
//        [[PlayManager shardPlayManager] resumeLayer:self.mp3Pic.layer];
    }
}
//播放下一首
- (IBAction)playNextOne:(UIButton *)sender {
    //如果播放是最后一首，则播放第一首
    if ((self.currentIndex == [[RequestManger shardManger] numberOfArrayCount] - 1)) {
        self.currentIndex = 0;
    } else {
        self.currentIndex++;
    }
    //设置信息
    [self setMusicInfoWithIndex:self.currentIndex];
}
//实现代理协议
- (void)playManagerDelegateFetchTotalTime:(NSString *)totalTime currentTime:(NSString *)currenytTime progress:(CGFloat)progress {
    self.totalTime.text = totalTime;
    self.currentTime.text = currenytTime;
    self.slider.value = progress;
    
    //实现图片旋转
    [UIView animateWithDuration:0.1 animations:^{
        self.mp3Pic.transform = CGAffineTransformRotate(self.mp3Pic.transform, M_PI / 60);
    }];
    //让歌词跟歌曲实时同步
    if ([self.timeArray containsObject:currenytTime]) {
        //返回当前时间所对应的时间
        NSInteger index = [self.timeArray indexOfObject:currenytTime];
        //让tableView对应的cell变成选中状态
        [self.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
    }
    
}
//自动播放下一首
- (void)playToNextMusic {
    [self playNextOne:nil];
}
#pragma mark - 歌词tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.timeArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    //被选中时的颜色
    cell.textLabel.highlightedTextColor = [UIColor redColor];
    //cell被选中的背景
    cell.selectedBackgroundView = [UIView new];
    
    //内容
    cell.textLabel.text = self.lyicArray[indexPath.row];
    //居中
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    //自适应换行
    cell.textLabel.numberOfLines = 0;
    return cell;
}
- (NSMutableArray *)lyicArray {
    if (!_lyicArray) {
        _lyicArray = [NSMutableArray array];
    }
    return _lyicArray;
}
- (NSMutableArray *)timeArray {
    if (!_timeArray) {
        _timeArray = [NSMutableArray array];
    }
    return _timeArray;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
