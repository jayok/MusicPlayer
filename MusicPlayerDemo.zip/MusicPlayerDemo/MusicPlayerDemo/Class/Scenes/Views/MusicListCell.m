//
//  MusicListCell.m
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/15.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import "MusicListCell.h"

@implementation MusicListCell

- (void)awakeFromNib {
    // Initialization code
}
- (void)cellGetDataForModel:(MusicModel *)model {
    [self.picImageView sd_setImageWithURL:[NSURL URLWithString:model.picUrl] placeholderImage:nil];
    self.name.text = model.name;
    self.singer.text = model.singer;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
