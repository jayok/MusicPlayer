//
//  MusicListCell.h
//  MusicPlayerDemo
//
//  Created by xalo on 16/6/15.
//  Copyright © 2016年 蓝鸥科技有限责任公司西安分公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicListCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *picImageView;

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *singer;
- (void)cellGetDataForModel:(MusicModel *)model;
@end
